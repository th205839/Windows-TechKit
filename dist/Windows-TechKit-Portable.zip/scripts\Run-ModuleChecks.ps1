# Run-ModuleChecks.ps1 - Prepare multiple modules via ModuleExecutor
. .\core\module-manager\ModuleManager.ps1
. .\core\module-manager\ModuleExecutor.ps1
$modules = @('Network','Inventory','Repair','Drivers','Backup','Security')
foreach ($m in $modules) {
    Write-Host "--- Preparing $m ---" -ForegroundColor Cyan
    try {
        $r = Invoke-TechKitModule -Name $m
        $r | Format-List * -Force
    }
    catch {
        Write-Host "Module $m failed: $($_.Exception.Message)" -ForegroundColor Red
    }
    Write-Host ""
}
